package page;

import base.BaseTest;
import org.openqa.selenium.support.PageFactory;

import java.util.Base64;

public class TheInternetHeroKuAppForkMeOnGitHubImageLink extends BaseTest {

    public TheInternetHeroKuAppForkMeOnGitHubImageLink (){
        PageFactory.initElements(driver,this);
    }

}
